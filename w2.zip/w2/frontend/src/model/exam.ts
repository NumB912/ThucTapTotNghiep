import type { Question } from "./question";

interface Exam{
    id:string,
    questions:Question[];

}